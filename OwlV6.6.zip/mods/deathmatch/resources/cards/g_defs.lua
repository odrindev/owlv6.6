MAX_CARDS = 5

local o = outputDebugString
-- outputDebugString = function(text, ...) o("[cards] " .. tostring(text), ...) end
outputDebugString = function() end
