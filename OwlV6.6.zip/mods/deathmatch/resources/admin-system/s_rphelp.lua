function fetchRules()	
	--[[
		local news = exports.mysql:forum_query_fetch_assoc("SELECT post_text FROM phpbb_ugposts WHERE post_subject ='Latest News!' LIMIT 1")
		local newNews = news["post_text"]
		]]
end
--addCommandHandler("fetchnews", updateNews, false, false)