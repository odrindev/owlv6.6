quests = {
	[1] = {
		{ "You were in a police chase and your car blew up, so you...", 3}, 
		{"... run to its spawn location and use it again.", "... bunny jump away from the police.", "... surrender, attempt to evade on foot, or RP stealing another."}
	},
	[2] = {
		{ "You were in a police chase and your car blew up, so you...", 3}, 
		{"... run to its spawn location and use it again.", "... bunny jump away from the police.", "... surrender, attempt to evade on foot, or RP stealing another."}
	},
	[3] = {
		{ "You were in a police chase and your car blew up, so you...", 3}, 
		{"... run to its spawn location and use it again.", "... bunny jump away from the police.", "... surrender, attempt to evade on foot, or RP stealing another."}
	},
	[4] = {
		{ "You were in a police chase and your car blew up, so you...", 3}, 
		{"... run to its spawn location and use it again.", "... bunny jump away from the police.", "... surrender, attempt to evade on foot, or RP stealing another."}
	},
	[5] = {
		{ "You were in a police chase and your car blew up, so you...", 3}, 
		{"... run to its spawn location and use it again.", "... bunny jump away from the police.", "... surrender, attempt to evade on foot, or RP stealing another."}
	},
	[6] = {
		{ "You were in a police chase and your car blew up, so you...", 3}, 
		{"... run to its spawn location and use it again.", "... bunny jump away from the police.", "... surrender, attempt to evade on foot, or RP stealing another."}
	},
}

