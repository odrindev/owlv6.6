function getServerTimestamp()
	return getElementData(root, "server:Timestamp")
end