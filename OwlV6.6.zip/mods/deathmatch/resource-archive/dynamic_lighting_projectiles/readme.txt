Resource: dynamic_Lighting_projectiles v1.0.5
contact: knoblauch700@o2.pl
Update v1.0.5
-fixed irregular flashing
Update v1.0.4
-fixed: Color always forced to {1,1,0,1}

This resource lets You create some light effects related to player activity - shooting,
throwing molotovs, vehicle explosions and so on. It uses custom functions
introduced in dynamic_lighting resource. It works for most of the weapons, except minigun
and flamethrower. I may do something about it, but later.

Have fun.

