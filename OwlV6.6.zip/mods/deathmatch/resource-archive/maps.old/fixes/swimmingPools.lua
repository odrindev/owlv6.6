local z

-- Don bigote hotel
createWater(995,-1022,41.7,1006,-1022,41.7,995,-1003,41.7,1006,-1003,41.7)

--Beach Road 1
createWater(163, -1756, 5.59, 176, -1756, 5.59, 163, -1749, 5.59, 176, -1749, 5.59, true)

--[[Palin Street 6
z=107.8
createWater(1324, -663, z, 1348, -663, z, 1324, -640, z, 1348, -640, z)]]