function removeFence()
	removeWorldModel(1412, 100, 1949, -1796, 13) -- Fences around IGS
end
